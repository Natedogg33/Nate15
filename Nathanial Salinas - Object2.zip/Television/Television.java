
/**
 * Write a description of class Television here.
 *
 * @author Nathanial Salinas
 * @version 9.7.18
 */
public class Television
{
    private int tvHeight;
    private int tvLength;
    private String tvColor;
    private String tvBrand;
    private boolean smartTV;
    public Television(int tvH, int tvL, String colour, String brand, boolean smart){
        tvHeight = tvH;
        tvLength = tvL;
        String tvColor = colour;
        String tvBrand = brand;
        smartTV = smart;
    }
    
    public Television(){
        this(20, 55, "Black", "Vizo", true);
    }
    
    public Television(int tvH, int tvL, String colour, boolean smart){
        tvHeight = tvH;
        tvLength = tvL;
        this.tvColor = colour;
        String tvBrand = "Vizo";
        smartTV = smart;
    }
    
    
    public Television(int tvL, int tvH){
        this(20, 55, "Black", "Vizo", true);
    }
    
    public void TurnOn(){
        System.out.println("Power on");
    }
    
    public void TurnUp(){
        System.out.println("Volume raised");
    }
    
    public void TurnOff(){
        System.out.println("Power off");
    }
    
    public int getTvLenght(){
        return tvLength;
    }
    
    public boolean getSmart(){
        return smartTV;
    }
    
    public int getTvHeight(){
        return tvHeight;
    }
    
    public String getTvColor(){
        return tvColor;
    }
    
    public String getTvBrand(){
        return tvBrand;
    }
    
    public void setTvColor(String colour){
        this.tvColor = colour;
    }
    
    public void setTVHeight(int tvH){
        this.tvHeight = tvH;
    }
    
    public void setChargePort(String brand){
        this.tvBrand = brand;
    }
    
    public void setDogColar(boolean smart){
        this.smartTV = smart; 
    }
}
