
/**
 * Write a description of class guessGame here.
 *
 * @author Nathanial Salinas
 * @version 8.30.18
 */
import java.util.Scanner;
public class guessGame
{
    public static void main(){
        int rand = (int)(Math.random()*101  + 100);
        int tries = 5;
        boolean win = false;
        while(tries > 0 && !win){
            Scanner scanner = new Scanner(System.in);
            System.out.println("Guess a number between 100-200:");
            int guess = scanner.nextInt();
            if(rand < guess){
                System.out.println("Your guess is too high try again");
                tries --;
                if(tries == 1){
                System.out.println("Last guess!");
            }else if(tries == 0)
                  System.out.println("Woops you are out of guesses:(");
            }else if(rand > guess){
                System.out.println("Your guess is too low try again");
                tries --;
                if(tries == 1){
                System.out.println("Last guess!");
            }else if(tries == 0)
                  System.out.println("Woops you are out of guesses:(");
            }else if(rand == guess){
                System.out.println("Congradulations your guess was correct.");
                win = true;
            }else{
                System.out.println("You are out of guess game over.");
            }
        }
        System.out.println("Game Over.");
    }
}
