
/**
 * Write a description of class Dog here.
 *
 * @author Nathanial Salinas
 * @version 9.6.18
 */

public class Dog{
    private int dogHeight;
    private int dogWidth;
    private int dogLength;
    private String dogColor;
    private String furType;
    private boolean dogColar;
    public Dog(int dogH, int dogW, int dogL, String colour, String furType, boolean colar ){
        dogHeight = dogH;
        dogWidth = dogW;
        dogLength = dogL;
        dogColor = colour;
        dogColar = colar;
    }
    
    public Dog(){
        this(4, 1, 5, "Golden","Shaggy", true);
    }
    
    public Dog(int dogL, int dogW, int dogH, String color, boolean colar){
        dogLength = dogL;
        dogWidth = dogW;
        dogHeight = dogH;
        this.dogColor = color;
        furType = "Shaggy";
        dogColar = colar;
    }
    
    public Dog(int dogL, int dogW){
        this(4, 1, 5, "Shaggy", true);
    }
    
    public void bark(){
        System.out.println("WOOF!");
    }
    
    public void walk(){
        System.out.println("Great exercise :)");
    }
    
    public void useRestroom(){
        System.out.println("Ewww....gross");
    }
    
    public int getDogWidth(){
        return dogWidth;
    }
    
    public int getDogLenght(){
        return dogLength;
    }
    
    public boolean getDogColar(){
        return dogColar;
    }
    
    public int getDogHeight(){
        return dogHeight;
    }
    
    public String getDogColor(){
        return dogColor;
    }
    
    public String getFurType(){
        return furType;
    }
    
    public void setColor(String colour){
        this.dogColor = colour;
    }
    
    public void setDogWidth(int dogW){
        this.dogWidth = dogW;
    }
    
    public void setDogHeight(int dogH){
        this.dogHeight = dogH;
    }
    
    public void setChargePort(String furT){
        this.furType = furT;
    }
    
    public void setDogColar(boolean colar){
        this.dogColar = colar; 
    }
}
