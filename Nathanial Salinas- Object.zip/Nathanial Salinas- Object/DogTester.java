
/**
 * Write a description of class DogTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DogTester
{
        public static void main(String[] args){
     Dog dog = new Dog();
     System.out.println("The dog's old width is: ");
     System.out.println(dog.getDogWidth());
     System.out.println("The old colour is: ");
     System.out.println(dog.getDogColor());
     System.out.println("The dog's old height is: ");
     System.out.println(dog.getDogHeight());
     System.out.println();
     
     dog.setColor("Black");
     System.out.println("The new colour is: ");
     System.out.println(dog.getDogColor());
     dog.setDogHeight(6);
     System.out.println("The new screen height is: ");
     System.out.println(dog.getDogHeight());
    }
}
