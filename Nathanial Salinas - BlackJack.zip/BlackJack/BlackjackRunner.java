
/**
 * Write a description of class BlackjackRunner here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class BlackjackRunner
{
    public static void main(String[] args){
        Hand playerHand = new Hand();
        Hand dealerHand = new Hand();
        boolean turn = true;
        boolean bust = false;
        int limit = 21;
        int dealerLimit = 17;

        System.out.println("You got a " + playerHand.getCardOne() + " and a " + playerHand.getCardTwo());
        System.out.println("Your total is " + playerHand.getTotal());

        //Player's Turn
        while(turn == true && !bust){
            Scanner scanner = new Scanner(System.in);
            System.out.println("Would you like to hit or stay?(Response must be lower cased.)");
            String response = scanner.next();
            if(response.equals("hit")){
                System.out.println("You got a " + playerHand.hit());
                System.out.println(playerHand.getTotal());
                if(playerHand.getTotal() > limit){
                    System.out.println("You busted :(");
                    bust = true;
                }
            }else if (response.equals("stay")){
                System.out.println("You stayed with " + playerHand.getTotal());
                turn = false;
            }
        }

        //Dealer's Turn
        dealerHand.getTotal();
        while (dealerHand.getTotal() < dealerLimit && !bust){
            dealerHand.hit();
            System.out.println("Dealer has a total of " +dealerHand.getTotal());
        }

        //Endgame
        System.out.println("The dealer stayed with " + dealerHand.getTotal());
        if(dealerHand.getTotal() > limit && !bust){
            System.out.println("The dealer bust. You WIN!!!!!");
        }else if(playerHand.getTotal() > dealerHand.getTotal() && !bust){
            System.out.println("Player wins.");
        }else if(playerHand.getTotal() < dealerHand.getTotal() && !bust){
            System.out.println("Dealer wins.");
        }else if (playerHand.getTotal() == dealerHand.getTotal()){
            System.out.println("You push");
        }

    }
}
