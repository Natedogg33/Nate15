
/**
 * Write a description of class BlackJack here.
 *
 * @author Nathanial Salinas
 * @version 9.10.18
 */
import java.util.Scanner;
public class Hand
{
    private int total;
    private int cardOne;
    private int cardTwo;
    
    public Hand(){
        cardOne = hit();
        cardTwo = hit();
    }
    public int hit(){
        int card = (int)(Math.random()*11 + 1);
        total += card;
        return card;
    }
    public int getTotal(){
        return total;
    }
    public int getCardOne(){
        return cardOne;
    }
    public int getCardTwo(){
        return cardTwo;
    }
}
