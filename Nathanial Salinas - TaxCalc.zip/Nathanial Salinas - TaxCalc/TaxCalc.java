
/**
 * Write a description of class TaxCalc here.
 *
 * @author Nathanial Salinas
 * @version 8.22.18
 */
import java.util.Scanner;
public class TaxCalc
{
    public static void grossIncome(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your gross income");
        int grossIncome = scanner.nextInt();
        Scanner dependents = new Scanner(System.in);
        System.out.println("Enter the number of dependents");
        int dependent = scanner.nextInt();
        int tableIncome;
        tableIncome = grossIncome - 10000 - 2000 * dependent;
        int incomeTax;
        incomeTax = tableIncome * 0.20;
        System.out.println("Your total is " + incomeTax);
    }
}
